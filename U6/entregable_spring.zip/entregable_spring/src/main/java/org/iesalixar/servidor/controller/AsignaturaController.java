package org.iesalixar.servidor.controller;

import org.springframework.stereotype.Controller;

@Controller
public class AsignaturaController {

}
